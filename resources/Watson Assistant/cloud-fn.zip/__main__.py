from ibmcloudant.cloudant_v1 import Document, CloudantV1
from ibm_watson import DiscoveryV2
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import json, sys, types
import pprint
import datetime


# Credentials for Plus beta discovery
apikey_discovery= 'dcKqh5F51MSgae0cCatvtIimnNmL9y_Zi6umpbd1oKQM'
url_discovery= 'https://api.us-south.discovery.watson.cloud.ibm.com/instances/c9c207a6-4d66-45c0-9b52-8a1e9e0003d5'

# environment name for plus beta discovery
project_id= '6d74e359-5dfb-4510-8391-14197ff26dd6'
collection_name='service-request'

# Credentials for Cloudant
CLOUDANT_URL="https://apikey-v2-1x264p9747hd9sgt3qfe8errhue6anqs84wkyrrmvoof:7703b9cefaa9643aa9b430231de1e4db@c5e4aba7-c645-4b54-91f7-e33f4b892adf-bluemix.cloudantnosqldb.appdomain.cloud"
CLOUDANT_APIKEY="-gY1y2_-NqWWP0PEJ5Bhpt8_ZmRFoUUfs677BWCtD1nT"


def authenticate():
# authenticate
    authenticator = IAMAuthenticator(apikey_discovery)
    discovery = DiscoveryV2(
        version='2019-11-22',
        authenticator=authenticator
    )

    discovery.set_service_url(url_discovery)

    response = discovery.list_collections(project_id=project_id).get_result()

    collections = [x for x in response['collections'] if x['name'] == collection_name]
    collection_id = collections[0]['collection_id']
    return discovery, collection_id


# print(json.dumps(response, indent=2))

def searchDiscovery(dict):
    discovery, col_id = authenticate()
    
    q = dict['query']
    searchResult = discovery.query(project_id=project_id, collection_ids=[col_id], query=q).get_result()
    # pprint.pprint(searchResult['results'][0]['text'])
    searchR = searchResult['results'][0]['text']

    return {"results": searchR}

def getMailDetails(dict, service):
    
    response = service.get_document(
      db='ticket-system',
      doc_id='cb357405004bb3b92c344c8a85684441'
    ).get_result()
    
    res = response['doc']['text']

    return {"results": res}

def myconverter(o):
    if isinstance(o, datetime.datetime):
        return o.isoformat()

def increaseCreditLimit(dict, service):
    # do today date
    d = {}
    d['date'] = datetime.datetime.now()
    date = json.dumps(d, default = myconverter)
    date_object = json.loads(date)

    # create document
    credit_doc = Document(
        createdAt= date_object["date"],
        name= dict['action'],
        creditCard= dict['creditCard'],
        creditLimit= dict['newLimit'])

    # push document to db
    response = service.post_document(db='abc-cloudant-db', document=credit_doc).get_result()
    # print(response['doc'][0])
    
    return {"results": response}

def main(dict):
    res = ""
    
    # authenticate cloudant first
    authenticator = IAMAuthenticator(CLOUDANT_APIKEY)

    service = CloudantV1(authenticator=authenticator)
    service.set_service_url(CLOUDANT_URL)

    
    # if user is asking about discovery mail details
    if (dict['action']=="searchDiscovery"):
        res= searchDiscovery(dict)

    
    # if user is asking about the credit limit
    if (dict['action']=="increase"):
        res= increaseCreditLimit(dict, service)

    # if user is asking about cloudant mail details
    if (dict['action']=="search"):
        res= getMailDetails(dict, service)
    
    return res

params = {
  "action": "search",
  "query": "debit card stuck"
}

x = main(params)

params = {
  "action": "increase",
  "creditCard": "ABC Bank Silver",
  "newLimit": "5000"
}

# y = main(params)
# print(y)
# print(x)